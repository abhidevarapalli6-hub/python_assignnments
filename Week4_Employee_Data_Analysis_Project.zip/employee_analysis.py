import pandas as pd


class EmployeeDataAnalyzer:
    def __init__(self, file_name):
        self.file_name = file_name
        self.data = None

    def load_data(self):
        self.data = pd.read_csv(self.file_name)
        print("Employee data loaded successfully.")
        print("\nEmployee Data:")
        print(self.data)

    def calculate_average_salary(self):
        average_salary = self.data["Salary"].mean()
        print(f"\nAverage Salary: ₹{average_salary:.2f}")
        return average_salary

    def department_count(self):
        counts = self.data["Department"].value_counts()
        print("\nDepartment Count:")
        print(counts)
        return counts

    def filter_by_salary(self, threshold):
        result = self.data[self.data["Salary"] > threshold]
        print(f"\nEmployees with salary above ₹{threshold}:")
        print(result)
        return result

    def export_results(self, result, output_file):
        result.to_csv(output_file, index=False)
        print(f"\nFiltered results exported to: {output_file}")


# Main program
file_name = "employee_data.csv"

analyzer = EmployeeDataAnalyzer(file_name)

# 1. Load CSV using Pandas
analyzer.load_data()

# 2. Calculate average salary
analyzer.calculate_average_salary()

# 3. Calculate department count
analyzer.department_count()

# 4. Filter employees above salary threshold
threshold = float(input("\nEnter salary threshold: "))
filtered_employees = analyzer.filter_by_salary(threshold)

# 5. Export filtered results to a new CSV
analyzer.export_results(filtered_employees, "filtered_employees.csv")
