# Week 4 – Employee Data Analysis Project

## Objective
A Python capstone project combining:
- File handling
- OOP
- Pandas
- CSV data handling
- Data filtering
- CSV export

## Project Tasks
1. Load employee CSV using Pandas.
2. Calculate average salary.
3. Count employees by department.
4. Filter employees above a salary threshold.
5. Export filtered employees to a new CSV file.

## Files
- `employee_data.csv` – input dataset
- `employee_analysis.py` – main Python program
- `filtered_employees_example.csv` – example output
- `README.md` – project documentation

## Installation
Install Pandas:

```bash
pip install pandas
```

## Run
Keep `employee_data.csv` and `employee_analysis.py` in the same folder, then run:

```bash
python employee_analysis.py
```

Enter a salary threshold when asked, for example:

```text
Enter salary threshold: 60000
```

The program creates:

```text
filtered_employees.csv
```
